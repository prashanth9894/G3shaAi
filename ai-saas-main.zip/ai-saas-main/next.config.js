/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ["github.com", "oaidalleapiprodscus.blob.core.windows.net"],
  },
};

module.exports = nextConfig;
