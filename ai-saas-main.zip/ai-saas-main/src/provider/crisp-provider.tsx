"use client";

import React from "react";
import CrispChat from "@/components/crisp-chat";

const CrispProvider = () => {
  return <CrispChat />;
};

export default CrispProvider;
